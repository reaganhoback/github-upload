# Moving Your Project to GitHub

This class will show you the many options you have available when moving a project to GitHub.
